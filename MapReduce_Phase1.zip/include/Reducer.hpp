#ifndef REDUCER_HPP
#define REDUCER_HPP

#include "Types.hpp"
#include "FileManager.hpp"

#include <string>
#include <vector>

namespace mr {

class Reducer {
public:
    explicit Reducer(FileManager& fm, const std::string& outputDir);

    // Sums the list of counts for a word and writes to output.
    void reduce(const std::string& word, const std::vector<int>& counts);

    // Writes SUCCESS file once the run completes.
    void markSuccess();

private:
    FileManager& fileManager_;
    std::string outputDir_;
};

} // namespace mr

#endif // REDUCER_HPP