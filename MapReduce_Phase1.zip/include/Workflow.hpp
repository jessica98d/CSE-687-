#ifndef WORKFLOW_HPP
#define WORKFLOW_HPP

#include "FileManager.hpp"
#include "Mapper.hpp"
#include "Reducer.hpp"
#include "Types.hpp"

#include <string>

namespace mr {

class Workflow {
public:
    Workflow(FileManager& fm,
             const std::string& inputDir,
             const std::string& tempDir,
             const std::string& outputDir);

    // Executes the full word-count MapReduce workflow.
    void run();

private:
    FileManager& fileManager_;
    std::string inputDir_;
    std::string tempDir_;
    std::string outputDir_;

    void doMapPhase();
    mr::Grouped doSortAndGroup();
    void doReducePhase(const mr::Grouped& grouped);
};

} // namespace mr

#endif // WORKFLOW_HPP