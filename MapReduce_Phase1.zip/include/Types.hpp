#ifndef TYPES_HPP
#define TYPES_HPP

#include <string>
#include <vector>
#include <unordered_map>

// Jessica's note:
// Common type aliases that make intent super clear.
// Keeping these near the top-level helps each component focus on logic, not typedef noise.
namespace mr {

using Word = std::string;
using Count = int;
using Line = std::string;

using KVPair = std::pair<Word, Count>;
using KVBuffer = std::vector<KVPair>;

// Grouped structure the Reducer expects: word -> list of counts
using Grouped = std::unordered_map<Word, std::vector<Count>>;

} // namespace mr

#endif // TYPES_HPP