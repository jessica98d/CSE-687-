#ifndef FILE_MANAGER_HPP
#define FILE_MANAGER_HPP

#include <string>
#include <vector>

namespace mr {

class FileManager {
public:
    FileManager() = default;

    // Returns all file paths (not directories) from a directory, unsorted.
    std::vector<std::string> listFiles(const std::string& directory) const;

    // Reads a text file, returning its lines. Throws on error.
    std::vector<std::string> readAllLines(const std::string& filePath) const;

    // Appends one line to a text file (creates the file if missing).
    void appendLine(const std::string& filePath, const std::string& line) const;

    // Writes full content to a file, overwriting any existing content.
    void writeAll(const std::string& filePath, const std::string& content) const;

    // Creates the directory path if it doesn't exist.
    void ensureDir(const std::string& directory) const;

    // Simple exists check (file or directory).
    bool exists(const std::string& path) const;
};

} // namespace mr

#endif // FILE_MANAGER_HPP