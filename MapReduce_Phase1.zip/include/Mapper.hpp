#ifndef MAPPER_HPP
#define MAPPER_HPP

#include "Types.hpp"
#include "FileManager.hpp"

#include <cstddef>
#include <string>

namespace mr {

class Mapper {
public:
    explicit Mapper(FileManager& fm, const std::string& tempDir, std::size_t flushThreshold = 1024);

    // Tokenizes one line from a file and buffers ("word",1) pairs.
    void map(const std::string& fileName, const std::string& line);

    // Forces a flush of any buffered pairs to disk.
    void flush();

private:
    FileManager& fileManager_;
    std::string tempDir_;
    KVBuffer buffer_;
    std::size_t flushThreshold_;

    // Writes current buffer to a single temp file (append), then clears buffer.
    void flushInternal();

    // Helper: normalize a token to lowercase letters/numbers only.
    static std::string normalizeToken(const std::string& token);
};

} // namespace mr

#endif // MAPPER_HPP