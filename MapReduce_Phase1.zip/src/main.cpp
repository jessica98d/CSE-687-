#include "Workflow.hpp"
#include "FileManager.hpp"

#include <iostream>
#include <string>

// Jessica's voice: no "using namespace std;" and clean error messaging.
// Also: by instructor requirement, this is a single-process, single-binary CLI.
int main(int argc, char** argv) {
    if (argc != 4) {
        std::cerr << "Usage: mapreduce <input_dir> <output_dir> <temp_dir>\n";
        return 1;
    }

    const std::string inputDir  = argv[1];
    const std::string outputDir = argv[2];
    const std::string tempDir   = argv[3];

    try {
        mr::FileManager fm;
        mr::Workflow wf(fm, inputDir, tempDir, outputDir);
        wf.run();
    } catch (const std::exception& ex) {
        std::cerr << "Fatal error: " << ex.what() << "\n";
        return 2;
    } catch (...) {
        std::cerr << "Unknown fatal error.\n";
        return 3;
    }

    // Per user's preference: no explicit 'return 0;' in main().
}