#include "Mapper.hpp"

#include <algorithm>
#include <cctype>
#include <sstream>

namespace mr {

Mapper::Mapper(FileManager& fm, const std::string& tempDir, std::size_t flushThreshold)
    : fileManager_(fm), tempDir_(tempDir), flushThreshold_(flushThreshold) {
    fileManager_.ensureDir(tempDir_);
}

std::string Mapper::normalizeToken(const std::string& token) {
    std::string out;
    out.reserve(token.size());
    for (unsigned char ch : token) {
        if (std::isalnum(ch)) {
            out.push_back(static_cast<char>(std::tolower(ch)));
        }
    }
    return out;
}

void Mapper::map(const std::string& fileName, const std::string& line) {
    (void)fileName; // For future: if we want to include file context, it's here.

    std::istringstream iss(line);
    std::string raw;
    while (iss >> raw) {
        std::string tok = normalizeToken(raw);
        if (!tok.empty()) {
            buffer_.emplace_back(tok, 1);
        }
    }
    if (buffer_.size() >= flushThreshold_) {
        flushInternal();
    }
}

void Mapper::flush() {
    if (!buffer_.empty()) {
        flushInternal();
    }
}

void Mapper::flushInternal() {
    // Append to a single well-known temp file for simplicity.
    const std::string tempFile = tempDir_ + "/intermediate.txt";

    // Each line: "word\t1"
    for (const auto& kv : buffer_) {
        fileManager_.appendLine(tempFile, kv.first + "\t" + std::to_string(kv.second));
    }
    buffer_.clear();
}

} // namespace mr