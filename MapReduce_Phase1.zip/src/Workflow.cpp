#include "Workflow.hpp"

#include <fstream>
#include <sstream>
#include <stdexcept>
#include <unordered_map>

namespace mr {

Workflow::Workflow(FileManager& fm,
                   const std::string& inputDir,
                   const std::string& tempDir,
                   const std::string& outputDir)
    : fileManager_(fm),
      inputDir_(inputDir),
      tempDir_(tempDir),
      outputDir_(outputDir) {
    fileManager_.ensureDir(tempDir_);
    fileManager_.ensureDir(outputDir_);
}

void Workflow::run() {
    // Jessica's note:
    // I like clean, explicit orchestration: map -> group -> reduce -> success marker.
    doMapPhase();
    Grouped grouped = doSortAndGroup();
    doReducePhase(grouped);
}

void Workflow::doMapPhase() {
    Mapper mapper(fileManager_, tempDir_, /*flushThreshold*/ 4096);

    const auto files = fileManager_.listFiles(inputDir_);
    if (files.empty()) {
        // No files to process is not fatal; we just produce empty output and SUCCESS.
        return;
    }
    for (const auto& path : files) {
        const auto lines = fileManager_.readAllLines(path);
        for (const auto& line : lines) {
            mapper.map(path, line);
        }
    }
    mapper.flush();
}

Grouped Workflow::doSortAndGroup() {
    Grouped grouped;
    const std::string tmpFile = tempDir_ + "/intermediate.txt";
    if (!fileManager_.exists(tmpFile)) {
        return grouped;
    }
    const auto lines = fileManager_.readAllLines(tmpFile);
    for (const auto& line : lines) {
        // Expect "word\t1"
        std::string word;
        int value = 0;

        std::size_t tabPos = line.find('\t');
        if (tabPos == std::string::npos) {
            continue; // silently skip bad lines
        }
        word = line.substr(0, tabPos);
        try {
            value = std::stoi(line.substr(tabPos + 1));
        } catch (...) {
            value = 0;
        }
        if (!word.empty() && value != 0) {
            grouped[word].push_back(value);
        }
    }
    return grouped;
}

void Workflow::doReducePhase(const Grouped& grouped) {
    Reducer reducer(fileManager_, outputDir_);
    for (const auto& kv : grouped) {
        reducer.reduce(kv.first, kv.second);
    }
    reducer.markSuccess();
}

} // namespace mr