#include "FileManager.hpp"

#include <filesystem>
#include <fstream>
#include <stdexcept>

namespace fs = std::filesystem;

namespace mr {

std::vector<std::string> FileManager::listFiles(const std::string& directory) const {
    std::vector<std::string> files;
    for (const auto& entry : fs::directory_iterator(directory)) {
        if (entry.is_regular_file()) {
            files.push_back(entry.path().string());
        }
    }
    return files;
}

std::vector<std::string> FileManager::readAllLines(const std::string& filePath) const {
    std::ifstream in(filePath);
    if (!in) {
        throw std::runtime_error("Failed to open file for reading: " + filePath);
    }
    std::vector<std::string> lines;
    std::string line;
    while (std::getline(in, line)) {
        lines.push_back(line);
    }
    return lines;
}

void FileManager::appendLine(const std::string& filePath, const std::string& line) const {
    std::ofstream out(filePath, std::ios::app);
    if (!out) {
        throw std::runtime_error("Failed to open file for appending: " + filePath);
    }
    out << line << "\n";
}

void FileManager::writeAll(const std::string& filePath, const std::string& content) const {
    std::ofstream out(filePath, std::ios::trunc);
    if (!out) {
        throw std::runtime_error("Failed to open file for writing: " + filePath);
    }
    out << content;
}

void FileManager::ensureDir(const std::string& directory) const {
    std::error_code ec;
    fs::create_directories(directory, ec);
    // We ignore errors intentionally here—existence checks will catch issues during IO.
    (void)ec;
}

bool FileManager::exists(const std::string& path) const {
    std::error_code ec;
    bool ok = fs::exists(path, ec);
    return ec ? false : ok;
}

} // namespace mr