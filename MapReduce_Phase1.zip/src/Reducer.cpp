#include "Reducer.hpp"

#include <numeric>  // std::accumulate

namespace mr {

Reducer::Reducer(FileManager& fm, const std::string& outputDir)
    : fileManager_(fm), outputDir_(outputDir) {
    fileManager_.ensureDir(outputDir_);
}

void Reducer::reduce(const std::string& word, const std::vector<int>& counts) {
    int total = std::accumulate(counts.begin(), counts.end(), 0);
    // Output format: "word,count"
    const std::string outPath = outputDir_ + "/word_counts.csv";
    fileManager_.appendLine(outPath, word + "," + std::to_string(total));
}

void Reducer::markSuccess() {
    const std::string marker = outputDir_ + "/SUCCESS";
    fileManager_.writeAll(marker, "");
}

} // namespace mr