#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
cmake -S . -B build
cmake --build build --config Release
./build/mapreduce sample_input output temp
echo "Done. See ./output/word_counts.csv and ./output/SUCCESS"