# MapReduce Phase 1 – Word Count (Single Process)

This is a clean, single-process C++17 implementation of a MapReduce-style **word count**, designed to meet the CSE 687 Phase 1 requirements:

- Command-line args: `<input_dir> <output_dir> <temp_dir>`
- FileManager abstracts all filesystem access
- Map → tokenizes and exports ("word", 1) to **temp** (buffered, flushes periodically)
- Sort/Group → creates `word -> [1, 1, ...]`
- Reduce → sums counts and writes `word_counts.csv` to **output**; writes an empty **SUCCESS** file on completion
- No threads, no processes, standard library + optional Boost

## Build

```bash
cd MapReduce_Phase1
cmake -S . -B build
cmake --build build --config Release
```

## Run

```bash
./build/mapreduce sample_input output temp
```

**Outputs**
- `output/word_counts.csv`
- `output/SUCCESS`

## Notes
- Logging currently uses simple `std::cerr`. Swap to Boost.Log later if desired.
- Token normalization keeps only alphanumeric characters and lowercases them.